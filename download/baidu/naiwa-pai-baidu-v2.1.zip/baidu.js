/* ===================== 百度版补丁（只在百度包里加载，最后一个加载）=====================
   1. 去掉打赏码、排行榜、云存档入口，以及所有引导去其他平台的文字（游戏里、信箱、更新说明、分享图）
   2. 手机上把画面缩进屏幕底部 86px 以上（底部是端返回按钮和 Home 指示条，按规范不能放按钮和核心文字）
   3. 存档只存在本机 */
(function(){
 window.BAIDU_BUILD=1;
 var BAD=new RegExp("[Bb]\u7ad9|\u54d4\u54e9|bili"+"bili|\u8d5e\u8d4f|\u626b\u4e00\u626b|\u626b\u5de6\u8fb9\u7684\u7801|Toy \u91cc");
 var HIDE=(window.BAIDU_HIDE||[]).concat(["#tZs","#zsBtn",".tRank","#tRank","#stCloud",".cloudSt","#cloudSt","#sCloud","#dyList","#shDl","#mnCloud"]);
 try{var st=document.createElement("style");st.textContent=HIDE.join(",")+"{display:none!important}";document.head.appendChild(st)}catch(e){}
 var REPL=[[/每天只有第一局算进日榜。?/g,""],[/[（(][^（）()]*([Bb]\u7ad9|Toy)[^（）()]*[）)]/g,""]];
 function fixText(s){REPL.forEach(function(r){s=s.replace(r[0],r[1])});return s}
 function cleanNode(t){var v=t.nodeValue;if(!v)return;var v2=fixText(v);if(v2!==v){t.nodeValue=v2;v=v2}if(!BAD.test(v))return;
  var el=t.parentElement;if(!el)return;var blk=el.closest("p,li,small,em,h4,label,.mlI,.tPlay,.lbMsg,.ltSig")||el;
  if(blk.id==="stage"||blk===document.body){t.nodeValue=v.replace(/[^。！，、\n]*([Bb]\u7ad9|\u8d5e\u8d4f)[^。！\n]*[。！]?/g,"");return}
  blk.remove()}
 function walk(n){if(!n)return;if(n.nodeType===3){cleanNode(n);return}if(n.nodeType!==1)return;if(n.tagName==="SCRIPT"||n.tagName==="STYLE")return;
  var w=document.createTreeWalker(n,NodeFilter.SHOW_TEXT,null),a=[],x;while((x=w.nextNode()))if(x.nodeValue&&(BAD.test(x.nodeValue)||/日榜|（|\(/.test(x.nodeValue)))a.push(x);a.forEach(cleanNode)}
 function start(){walk(document.body);try{new MutationObserver(function(ms){ms.forEach(function(m){if(m.type==="characterData")cleanNode(m.target);else m.addedNodes&&m.addedNodes.forEach(walk)})}).observe(document.body,{childList:true,subtree:true,characterData:true})}catch(e){}}
 if(document.body)start();else addEventListener("DOMContentLoaded",start);
 // 分享图（canvas）上的文字
 try{var ft=CanvasRenderingContext2D.prototype.fillText;CanvasRenderingContext2D.prototype.fillText=function(s){if(typeof s==="string"&&BAD.test(s)){arguments[0]=/奶蛙之塔/.test(s)?"奶蛙之塔 · 一起来爬塔":/奶蛙牌/.test(s)?"奶蛙牌 · 奶蛙工作室":"奶蛙工作室"}return ft.apply(this,arguments)}}catch(e){}
 // 底部 86px 安全区：手机上画面整体缩到这条线以上
 var touch=false;try{touch=matchMedia("(pointer:coarse)").matches||("ontouchstart" in window)}catch(e){}
 window.BAIDU_SAFE_BOTTOM=touch?86:0;
 function wrapFit(){if(typeof fit!=="function"||fit.__bd)return;var f0=fit;fit=function(){var r=f0.apply(this,arguments);try{var st=document.getElementById("stage");if(!st)return r;
   // 电脑上窗口竖着：不转 90°，横版画面等比缩小放在中间（电脑屏幕转不了）
   if(!touch&&/rotate/.test(st.style.transform||"")){var W0=innerWidth,H0=innerHeight;var s0=Math.min(W0/1280,H0/720);st.style.width="1280px";st.style.left=(W0/2)+"px";st.style.top=(H0/2)+"px";st.style.transform="translate(-50%,-50%) scale("+s0+")";document.body.classList.remove("port");try{_stR=null}catch(e){}}
   var sb=window.BAIDU_SAFE_BOTTOM;if(!sb)return r;
   var vv=window.visualViewport,H=innerHeight,oy=0;if(vv&&vv.height>0){H=Math.min(H,vv.height);oy=vv.offsetTop||0}var de=document.documentElement;if(de.clientHeight>0)H=Math.min(H,de.clientHeight);
   var R=st.getBoundingClientRect(),avail=H-sb;if(R.height<=0)return r;var k=Math.min(1,avail/R.height);var tf=st.style.transform||"";var m=/scale\(([\d.]+)\)/.exec(tf);
   if(m&&k<1){st.style.transform=tf.replace(/scale\([\d.]+\)/,"scale("+(+m[1]*k)+")")}var R2=st.getBoundingClientRect();if(R2.bottom>avail+oy-0.5){st.style.top=(oy+avail/2)+"px"}}catch(e){}return r};fit.__bd=1;var re=function(){try{fit()}catch(e){}};addEventListener("resize",re);if(window.visualViewport)visualViewport.addEventListener("resize",re);addEventListener("orientationchange",function(){[80,300,700,1300].forEach(function(t){setTimeout(re,t)})});re()}
 if(document.readyState!=="loading")wrapFit();addEventListener("DOMContentLoaded",wrapFit);addEventListener("load",function(){wrapFit();try{fit()}catch(e){}});
})();
